In ChatGPT.bat change launcherPath with your opera browser location
example: C:\Users\alexei\AppData\Local\Programs\Opera